package com.example.matheus.desafio01;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;
import java.util.Scanner;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Enviar(View v) {
        Random ran = new Random();
        int num = ran.nextInt(10)+1;
        int erros = 0, testeInt = 0;


        TextView etiqueta = (TextView) findViewById(R.id.textView);

        for(int i = 0;i<3;i++){
            System.out.println("Digite a tentativa: ");

            EditText userInput = findViewById(R.id.editText);
            String teste = userInput.getText().toString();
            testeInt = Integer.parseInt(teste);

            if(testeInt == num){
                etiqueta.setText(getResources().getString(R.string.lblGreat));
                i = 3;
            }else{
                etiqueta.setText(getResources().getString(R.string.lblWrong));
                erros++;
            }
        }
        if(erros == 3){
            etiqueta.setText(getResources().getString(R.string.lblWrong2));
        }
    }


}
